//
//  WQPermissions.h
//  WQ Files - custom POSIX permission editor
//  GPL-3.0-or-later.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// A sheet that lets the user toggle read / write / execute for owner,
/// group and others, then applies the result with chmod(2).
@interface WQPermissionsViewController : UIViewController

/// Called on the main queue after chmod succeeds; value is the full mode.
@property (nonatomic, copy, nullable) void (^onApply)(int mode);

- (instancetype)initWithPath:(NSString *)path;

@end

NS_ASSUME_NONNULL_END
