//
//  WQPermissions.m
//  WQ Files - custom POSIX permission editor
//  GPL-3.0-or-later.
//

#import "WQPermissions.h"
#import "WQLocalization.h"
#import <sys/stat.h>
#import <errno.h>
#import <string.h>

@interface WQPermissionsViewController ()

@property (nonatomic, copy) NSString *path;
@property (nonatomic, assign) mode_t currentMode;
@property (nonatomic, strong) UILabel *modeLabel;
@property (nonatomic, strong) NSMutableArray<UISwitch *> *switches;

- (void)buildInterface;
- (UILabel *)headerLabel:(NSString *)title;
- (UIView *)rowWithTitle:(NSString *)title bit:(mode_t)bit;
- (void)toggleChanged;
- (mode_t)composedMode;
- (void)cancelTapped;
- (void)saveTapped;
- (void)presentFailure:(NSString *)reason;

@end

@implementation WQPermissionsViewController

- (instancetype)initWithPath:(NSString *)path
{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _path = [path copy];
        _switches = [NSMutableArray arrayWithCapacity:9];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.title = WQLocalizedNullable(@"File Permissions");
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;

    self.navigationItem.leftBarButtonItem =
        [[UIBarButtonItem alloc] initWithTitle:WQLocalizedNullable(@"Cancel")
                                         style:UIBarButtonItemStylePlain
                                        target:self
                                        action:@selector(cancelTapped)];
    self.navigationItem.rightBarButtonItem =
        [[UIBarButtonItem alloc] initWithTitle:WQLocalizedNullable(@"Save")
                                         style:UIBarButtonItemStyleDone
                                        target:self
                                        action:@selector(saveTapped)];

    struct stat st;
    if (stat(_path.fileSystemRepresentation, &st) == 0) {
        _currentMode = st.st_mode & 07777;
    } else {
        _currentMode = 0644;
        self.navigationItem.rightBarButtonItem.enabled = NO;
    }
    [self buildInterface];
}

#pragma mark - Interface

- (void)buildInterface
{
    UIScrollView *scroll = [[UIScrollView alloc] init];
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    scroll.alwaysBounceVertical = YES;
    [self.view addSubview:scroll];

    UIStackView *column = [[UIStackView alloc] init];
    column.translatesAutoresizingMaskIntoConstraints = NO;
    column.axis = UILayoutConstraintAxisVertical;
    column.spacing = 10;
    column.layoutMargins = UIEdgeInsetsMake(16, 16, 24, 16);
    column.layoutMarginsRelativeArrangement = YES;
    [scroll addSubview:column];

    [NSLayoutConstraint activateConstraints:@[
        [scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [scroll.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [scroll.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [scroll.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
        [column.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor],
        [column.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor],
        [column.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor],
        [column.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor],
        [column.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor],
    ]];

    UILabel *pathLabel = [[UILabel alloc] init];
    pathLabel.text = _path;
    pathLabel.numberOfLines = 2;
    pathLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    pathLabel.textColor = UIColor.secondaryLabelColor;
    [column addArrangedSubview:pathLabel];

    UIStackView *modeRow = [[UIStackView alloc] init];
    modeRow.axis = UILayoutConstraintAxisHorizontal;
    modeRow.alignment = UIStackViewAlignmentCenter;

    UILabel *modeTitle = [[UILabel alloc] init];
    modeTitle.text = WQLocalizedNullable(@"Current mode");
    modeTitle.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];

    _modeLabel = [[UILabel alloc] init];
    _modeLabel.font = [UIFont monospacedSystemFontOfSize:17 weight:UIFontWeightSemibold];
    _modeLabel.textColor = self.view.tintColor;
    _modeLabel.textAlignment = NSTextAlignmentRight;
    _modeLabel.text = [NSString stringWithFormat:@"%03o", (unsigned int)_currentMode];
    [_modeLabel setContentHuggingPriority:UILayoutPriorityRequired
                                  forAxis:UILayoutConstraintAxisHorizontal];

    [modeRow addArrangedSubview:modeTitle];
    [modeRow addArrangedSubview:_modeLabel];
    [column addArrangedSubview:modeRow];

    [column addArrangedSubview:[self headerLabel:WQLocalizedNullable(@"Owner")]];
    [column addArrangedSubview:[self rowWithTitle:WQLocalizedNullable(@"Read") bit:0400]];
    [column addArrangedSubview:[self rowWithTitle:WQLocalizedNullable(@"Write") bit:0200]];
    [column addArrangedSubview:[self rowWithTitle:WQLocalizedNullable(@"Execute") bit:0100]];

    [column addArrangedSubview:[self headerLabel:WQLocalizedNullable(@"Group")]];
    [column addArrangedSubview:[self rowWithTitle:WQLocalizedNullable(@"Read") bit:040]];
    [column addArrangedSubview:[self rowWithTitle:WQLocalizedNullable(@"Write") bit:020]];
    [column addArrangedSubview:[self rowWithTitle:WQLocalizedNullable(@"Execute") bit:010]];

    [column addArrangedSubview:[self headerLabel:WQLocalizedNullable(@"Others")]];
    [column addArrangedSubview:[self rowWithTitle:WQLocalizedNullable(@"Read") bit:04]];
    [column addArrangedSubview:[self rowWithTitle:WQLocalizedNullable(@"Write") bit:02]];
    [column addArrangedSubview:[self rowWithTitle:WQLocalizedNullable(@"Execute") bit:01]];

    UILabel *hint = [[UILabel alloc] init];
    hint.text = WQLocalizedNullable(@"Tap Save at the top right to apply. Setting 0444 makes even this app unable to write.");
    hint.numberOfLines = 0;
    hint.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    hint.textColor = UIColor.secondaryLabelColor;
    [column addArrangedSubview:hint];
}

- (UILabel *)headerLabel:(NSString *)title
{
    UILabel *label = [[UILabel alloc] init];
    label.text = title;
    label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    label.textColor = UIColor.secondaryLabelColor;
    return label;
}

- (UIView *)rowWithTitle:(NSString *)title bit:(mode_t)bit
{
    UILabel *label = [[UILabel alloc] init];
    label.text = title;
    label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];

    UISwitch *toggle = [[UISwitch alloc] init];
    toggle.on = (_currentMode & bit) != 0;
    [toggle addTarget:self
                action:@selector(toggleChanged)
      forControlEvents:UIControlEventValueChanged];
    [_switches addObject:toggle];

    UIStackView *row = [[UIStackView alloc] initWithArrangedSubviews:@[label, toggle]];
    row.axis = UILayoutConstraintAxisHorizontal;
    row.alignment = UIStackViewAlignmentCenter;
    row.spacing = 12;
    return row;
}

#pragma mark - Actions

- (void)toggleChanged
{
    _modeLabel.text = [NSString stringWithFormat:@"%03o", (unsigned int)[self composedMode]];
}

- (mode_t)composedMode
{
    static const mode_t bits[9] = {0400, 0200, 0100, 040, 020, 010, 04, 02, 01};
    mode_t mode = 0;
    NSUInteger count = MIN(_switches.count, (NSUInteger)9);
    for (NSUInteger index = 0; index < count; index++) {
        if (_switches[index].isOn) mode |= bits[index];
    }
    return mode;
}

- (void)cancelTapped
{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

- (void)saveTapped
{
    mode_t newMode = [self composedMode];
    if (chmod(_path.fileSystemRepresentation, newMode) != 0) {
        NSString *reason = [NSString stringWithUTF8String:strerror(errno)];
        if (!reason.length) reason = @"Unknown error";
        [self presentFailure:reason];
        return;
    }
    if (self.onApply) self.onApply((int)newMode);
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

- (void)presentFailure:(NSString *)reason
{
    UIAlertController *alert =
        [UIAlertController alertControllerWithTitle:WQLocalizedNullable(@"Permission change failed")
                                             message:reason
                                      preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:WQLocalizedNullable(@"OK")
                                              style:UIAlertActionStyleDefault
                                            handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
